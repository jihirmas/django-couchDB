from django.db import models
from django.conf import settings


# set up connection to couchdb in code



# Create your models here.
